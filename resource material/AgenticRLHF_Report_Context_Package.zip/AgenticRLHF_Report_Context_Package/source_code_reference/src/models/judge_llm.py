"""Judge LLM backends (Ollama by default; optional cloud providers)."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any

import config
from src.models.ollama_client import OllamaClient


class JudgeLLM:
    """Thin chat completion wrapper used only by the supervisory judge."""

    def __init__(
        self,
        provider: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
    ):
        self.provider = (provider or config.JUDGE_PROVIDER).lower()
        self.model = model or config.JUDGE_MODEL
        self.base_url = (base_url or config.OLLAMA_BASE_URL).rstrip("/")
        self.client = OllamaClient(self.base_url)
        self.active_model = self.model
        self.last_error: str | None = None

    def available(self) -> tuple[bool, str]:
        if self.provider == "ollama":
            names = self.client.list_models()
            if not names:
                return False, f"Ollama unavailable at {self.base_url}"
            candidates = [self.model, *config.JUDGE_FALLBACK_MODELS]
            for cand in candidates:
                if self.client.has_model(cand):
                    return True, f"Ollama judge candidate available: {cand}"
            return False, f"No judge models found. Have: {names}. Wanted: {candidates}"
        if self.provider == "openai":
            return bool(os.getenv("OPENAI_API_KEY")), "OPENAI_API_KEY required"
        if self.provider == "groq":
            return bool(os.getenv("GROQ_API_KEY")), "GROQ_API_KEY required"
        if self.provider in {"gemini", "google"}:
            return bool(os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")), (
                "GOOGLE_API_KEY/GEMINI_API_KEY required"
            )
        return False, f"Unknown judge provider: {self.provider}"

    def _available_ram_gb(self) -> float | None:
        try:
            import psutil

            return psutil.virtual_memory().available / 1e9
        except Exception:
            return None

    def _resolve_ollama_model(self) -> str:
        candidates = [self.model, *config.JUDGE_FALLBACK_MODELS]
        ram = self._available_ram_gb()
        # llama3.1:8b needs substantial free memory on CPU; skip when RAM is tight
        filtered = []
        for cand in candidates:
            base = cand.split(":")[0]
            if base.startswith("llama3.1") and ram is not None and ram < 6.0:
                continue
            filtered.append(cand)
        if not filtered:
            filtered = list(candidates)
        for cand in filtered:
            if self.client.has_model(cand):
                return cand
        raise RuntimeError(
            f"No judge Ollama model available among {candidates}. "
            f"Pull one with: ollama pull {self.model}"
        )

    def resolve_info(self) -> dict[str, Any]:
        """Which judge model would actually run right now, and why (for honest UI labels)."""
        info: dict[str, Any] = {
            "provider": self.provider,
            "configured": self.model,
            "active": None,
            "is_fallback": False,
            "reason": None,
            "available_ram_gb": None,
        }
        if self.provider != "ollama":
            info["active"] = self.model
            return info
        ram = self._available_ram_gb()
        info["available_ram_gb"] = None if ram is None else round(ram, 1)
        try:
            active = self._resolve_ollama_model()
        except Exception as e:
            info["reason"] = str(e)
            return info
        info["active"] = active
        if active != self.model:
            info["is_fallback"] = True
            if self.model.split(":")[0].startswith("llama3.1") and ram is not None and ram < 6.0:
                info["reason"] = (
                    f"{self.model} skipped: {ram:.1f} GB RAM available, 6 GB required on CPU"
                )
            else:
                info["reason"] = f"{self.model} not available in Ollama"
        return info

    def chat(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int | None = None,
    ) -> str:
        max_tokens = max_tokens or config.JUDGE_MAX_TOKENS
        if self.provider == "ollama":
            return self._ollama_chat(messages, temperature=temperature, max_tokens=max_tokens)
        if self.provider == "openai":
            return self._openai_compatible(
                base_url="https://api.openai.com/v1",
                api_key=os.environ["OPENAI_API_KEY"],
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        if self.provider == "groq":
            return self._openai_compatible(
                base_url="https://api.groq.com/openai/v1",
                api_key=os.environ["GROQ_API_KEY"],
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        if self.provider in {"gemini", "google"}:
            return self._gemini_chat(messages, temperature=temperature, max_tokens=max_tokens)
        raise RuntimeError(f"Unsupported judge provider: {self.provider}")

    def _ollama_chat(
        self, messages: list[dict[str, str]], temperature: float, max_tokens: int
    ) -> str:
        model = self._resolve_ollama_model()
        self.active_model = model
        try:
            out = self.client.chat(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                json_mode=True,
                num_ctx=4096,
            )
            self.last_error = None
            return out
        except RuntimeError as e:
            self.last_error = str(e)
            err = str(e).lower()
            # Retry without JSON mode, then try next fallback model on OOM
            try:
                out = self.client.chat(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    json_mode=False,
                    num_ctx=2048,
                )
                self.last_error = None
                return out
            except RuntimeError as e2:
                self.last_error = str(e2)
                if "out-of-memory" in err or "failed to allocate" in err or "out-of-memory" in str(e2).lower():
                    for fb in config.JUDGE_FALLBACK_MODELS:
                        if fb == model or not self.client.has_model(fb):
                            continue
                        try:
                            self.active_model = fb
                            return self.client.chat(
                                model=fb,
                                messages=messages,
                                temperature=temperature,
                                max_tokens=max_tokens,
                                json_mode=False,
                                num_ctx=2048,
                            )
                        except Exception:
                            continue
                raise

    def _openai_compatible(
        self,
        base_url: str,
        api_key: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> str:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }
        req = urllib.request.Request(
            f"{base_url.rstrip('/')}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]

    def _gemini_chat(
        self, messages: list[dict[str, str]], temperature: float, max_tokens: int
    ) -> str:
        api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("Missing GOOGLE_API_KEY / GEMINI_API_KEY")
        parts = []
        for m in messages:
            parts.append(f"{m['role'].upper()}:\n{m['content']}")
        prompt = "\n\n".join(parts) + "\n\nASSISTANT (JSON only):"
        model = self.model if self.model.startswith("gemini") else "gemini-1.5-flash"
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{model}:generateContent?key={api_key}"
        )
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
                "responseMimeType": "application/json",
            },
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["candidates"][0]["content"]["parts"][0]["text"]
