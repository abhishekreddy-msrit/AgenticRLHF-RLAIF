"""Target LLM backends: Ollama (demo quality) + Transformers (trainable / adapter)."""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any, Protocol

import torch

import config
from src.models.ollama_client import OllamaClient


class TargetBackend(Protocol):
    def generate(
        self,
        prompt: str,
        history: list[dict[str, str]] | None = None,
        max_new_tokens: int | None = None,
        temperature: float = 0.7,
    ) -> str: ...

    def unload(self) -> None: ...

    def info(self) -> dict[str, Any]: ...

    @property
    def is_optimized(self) -> bool: ...


class TransformersTarget:
    """HF Transformers target — used for DPO/LoRA training and optimized inference."""

    _lock = threading.Lock()

    def __init__(
        self,
        model_id: str | None = None,
        adapter_path: str | Path | None = None,
        device: str | None = None,
        system_prompt: str | None = None,
    ):
        self.model_id = model_id or config.TARGET_HF_MODEL_ID
        self.device = device or config.DEVICE
        if self.device == "cuda" and not torch.cuda.is_available():
            self.device = "cpu"
        self.adapter_path = Path(adapter_path) if adapter_path else None
        self.system_prompt = system_prompt or config.TARGET_SYSTEM_PROMPT
        self.backend_name = "transformers"
        self.tokenizer = None
        self.model = None
        self._loaded = False
        self._adapter_loaded = False
        self._adapter_base_model: str | None = None
        self.load_error: str | None = None

    @property
    def is_optimized(self) -> bool:
        """True only when an adapter path exists AND was successfully loaded."""
        return bool(self._adapter_loaded)

    def load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            from transformers import AutoModelForCausalLM, AutoTokenizer

            try:
                self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
                if self.tokenizer.pad_token is None:
                    self.tokenizer.pad_token = self.tokenizer.eos_token
                self.model = AutoModelForCausalLM.from_pretrained(
                    self.model_id,
                    dtype=torch.float32,
                    low_cpu_mem_usage=True,
                )
                self._adapter_loaded = False
                self._adapter_base_model = None
                if self.adapter_path and self.adapter_path.exists():
                    from peft import PeftModel
                    import json as _json

                    cfg_path = self.adapter_path / "adapter_config.json"
                    if cfg_path.exists():
                        cfg = _json.loads(cfg_path.read_text(encoding="utf-8"))
                        self._adapter_base_model = cfg.get("base_model_name_or_path")
                        if (
                            self._adapter_base_model
                            and self._adapter_base_model != self.model_id
                        ):
                            raise RuntimeError(
                                f"Adapter base model mismatch: adapter={self._adapter_base_model} "
                                f"current={self.model_id}"
                            )
                    self.model = PeftModel.from_pretrained(self.model, str(self.adapter_path))
                    self._adapter_loaded = True
                self.model.to(self.device)
                self.model.eval()
                self._loaded = True
                self.load_error = None
            except Exception as e:
                self.load_error = str(e)
                self._adapter_loaded = False
                raise

    def unload(self) -> None:
        self.model = None
        self.tokenizer = None
        self._loaded = False
        self._adapter_loaded = False
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def _format_chat(self, prompt: str, history: list[dict[str, str]] | None = None) -> str:
        messages: list[dict[str, str]] = [{"role": "system", "content": self.system_prompt}]
        if history:
            for turn in history:
                role = turn.get("role", "user")
                if role in {"user", "assistant"}:
                    messages.append({"role": role, "content": turn["content"]})
        messages.append({"role": "user", "content": prompt})
        if hasattr(self.tokenizer, "apply_chat_template"):
            try:
                return self.tokenizer.apply_chat_template(
                    messages, tokenize=False, add_generation_prompt=True
                )
            except Exception:
                pass
        parts = [f"System: {self.system_prompt}"]
        for m in messages[1:]:
            parts.append(f"{m['role'].capitalize()}: {m['content']}")
        parts.append("Assistant:")
        return "\n".join(parts)

    @torch.inference_mode()
    def generate(
        self,
        prompt: str,
        history: list[dict[str, str]] | None = None,
        max_new_tokens: int | None = None,
        temperature: float = 0.7,
    ) -> str:
        self.load()
        assert self.model is not None and self.tokenizer is not None
        text = self._format_chat(prompt, history=history)
        inputs = self.tokenizer(text, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        max_new_tokens = max_new_tokens or config.MAX_NEW_TOKENS
        gen_kwargs: dict[str, Any] = {
            "max_new_tokens": max_new_tokens,
            "do_sample": temperature > 0,
            "pad_token_id": self.tokenizer.pad_token_id,
            "eos_token_id": self.tokenizer.eos_token_id,
        }
        if temperature > 0:
            gen_kwargs["temperature"] = max(temperature, 1e-5)
        output = self.model.generate(**inputs, **gen_kwargs)
        new_tokens = output[0][inputs["input_ids"].shape[-1] :]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    def info(self) -> dict[str, Any]:
        return {
            "backend": self.backend_name,
            "model_id": self.model_id,
            "device": self.device,
            "loaded": self._loaded,
            "optimized": self.is_optimized,
            "adapter_path": str(self.adapter_path) if self.adapter_path else None,
            "adapter_loaded": self._adapter_loaded,
            "adapter_base_model": self._adapter_base_model,
            "adapter_compatible": True,
            "has_tools": False,
            "system_prompt": self.system_prompt,
            "load_error": self.load_error,
            "note": (
                "Optimized=true only after PEFT adapter successfully loads on matching base model."
            ),
        }


class OllamaTarget:
    """Ollama target — higher-quality local demo inference. No adapter support."""

    def __init__(
        self,
        model: str | None = None,
        system_prompt: str | None = None,
        client: OllamaClient | None = None,
    ):
        self.model_id = model or config.TARGET_OLLAMA_MODEL
        self.system_prompt = system_prompt or config.TARGET_SYSTEM_PROMPT
        self.client = client or OllamaClient()
        self.backend_name = "ollama"
        self.load_error: str | None = None
        self.last_generation_meta: dict[str, Any] = {}

    @property
    def is_optimized(self) -> bool:
        return False

    def unload(self) -> None:
        # Ollama manages its own process memory; nothing to free in-process.
        return

    def generate(
        self,
        prompt: str,
        history: list[dict[str, str]] | None = None,
        max_new_tokens: int | None = None,
        temperature: float = 0.7,
    ) -> str:
        if not self.client.has_model(self.model_id):
            self.load_error = f"Ollama model '{self.model_id}' not found. Run: ollama pull {self.model_id}"
            raise RuntimeError(self.load_error)
        messages: list[dict[str, str]] = [{"role": "system", "content": self.system_prompt}]
        if history:
            for turn in history[-6:]:
                role = turn.get("role", "user")
                if role in {"user", "assistant"}:
                    messages.append({"role": role, "content": turn["content"]})
        messages.append({"role": "user", "content": prompt})
        try:
            text = self.client.chat(
                model=self.model_id,
                messages=messages,
                temperature=temperature,
                max_tokens=max_new_tokens or config.MAX_NEW_TOKENS,
                json_mode=False,
            )
            self.load_error = None
            self.last_generation_meta = dict(getattr(self.client, "last_meta", {}) or {})
            return text.strip()
        except Exception as e:
            self.load_error = str(e)
            raise

    def info(self) -> dict[str, Any]:
        return {
            "backend": self.backend_name,
            "model_id": self.model_id,
            "device": "ollama",
            "loaded": self.client.has_model(self.model_id),
            "optimized": False,
            "adapter_path": None,
            "adapter_compatible": False,
            "has_tools": False,
            "system_prompt": self.system_prompt,
            "load_error": self.load_error,
            "note": (
                "Ollama GGUF inference cannot load Hugging Face PEFT LoRA adapters. "
                "Use the Transformers/SmolLM2 path for optimized (adapter) inference."
            ),
        }


def create_target(
    mode: str = "playground",
    ollama_model: str | None = None,
    use_adapter: bool = False,
    adapter_path: str | Path | None = None,
) -> TransformersTarget | OllamaTarget:
    """
    mode:
      - playground: Ollama Qwen (or configured Ollama model)
      - train_base: HF SmolLM2 without adapter
      - optimized: HF SmolLM2 + LoRA adapter
    """
    if mode == "optimized" or use_adapter:
        return TransformersTarget(adapter_path=adapter_path)
    if mode == "train_base" or mode == "transformers":
        return TransformersTarget(adapter_path=None)
    # playground default
    backend = config.TARGET_BACKEND
    if backend == "transformers":
        return TransformersTarget(adapter_path=None)
    return OllamaTarget(model=ollama_model or config.TARGET_OLLAMA_MODEL)


# Back-compat alias used throughout V0.1 code
TargetLLM = TransformersTarget
