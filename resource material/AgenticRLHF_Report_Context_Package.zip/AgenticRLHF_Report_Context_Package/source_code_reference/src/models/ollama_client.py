"""Shared Ollama HTTP client for chat and embeddings."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

import config


class OllamaClient:
    def __init__(self, base_url: str | None = None):
        self.base_url = (base_url or config.OLLAMA_BASE_URL).rstrip("/")
        self.last_meta: dict[str, Any] = {}

    def list_models(self) -> list[str]:
        try:
            with urllib.request.urlopen(f"{self.base_url}/api/tags", timeout=5) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            return [m.get("name", "") for m in data.get("models", [])]
        except Exception:
            return []

    def has_model(self, model: str) -> bool:
        names = self.list_models()
        if model in names:
            return True
        base = model.split(":")[0]
        return any(n == model or n.startswith(base + ":") or n.startswith(base) for n in names)

    def chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int = 512,
        json_mode: bool = False,
        num_ctx: int = 4096,
        timeout: int = 180,
    ) -> str:
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
                "num_ctx": num_ctx,
            },
        }
        if json_mode:
            payload["format"] = "json"
        data = self._post("/api/chat", payload, timeout=timeout)
        # Generation metadata for honest reporting (e.g. done_reason == "length"
        # means the reply was cut off by the token limit).
        self.last_meta = {
            "model": data.get("model") or model,
            "done_reason": data.get("done_reason"),
            "eval_count": data.get("eval_count"),
            "max_tokens": max_tokens,
        }
        return data.get("message", {}).get("content", "")

    def generate(
        self,
        model: str,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 256,
        timeout: int = 180,
    ) -> str:
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return self.chat(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            json_mode=False,
            timeout=timeout,
        )

    def embed(self, model: str, text: str, timeout: int = 60) -> list[float]:
        # Prefer /api/embeddings; fall back to /api/embed if needed.
        try:
            data = self._post(
                "/api/embeddings",
                {"model": model, "prompt": text},
                timeout=timeout,
            )
            if "embedding" in data:
                return list(data["embedding"])
        except Exception:
            pass
        data = self._post(
            "/api/embed",
            {"model": model, "input": text},
            timeout=timeout,
        )
        embeddings = data.get("embeddings")
        if embeddings:
            return list(embeddings[0])
        if "embedding" in data:
            return list(data["embedding"])
        raise RuntimeError(f"No embedding returned from Ollama for model={model}")

    def _post(self, path: str, payload: dict, timeout: int = 120) -> dict:
        req = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama {path} failed ({e.code}): {body}") from e
