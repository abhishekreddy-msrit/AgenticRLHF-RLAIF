# SOURCE_CODE_INDEX.md — Curated implementation reference

Purpose: Help Claude/Pavan locate the code that implements each subsystem described in the technical handover.
Paths below are relative to `source_code_reference/` and mirror the repository layout.

## Entry points and configuration

| File | Why it matters for the report |
|------|-------------------------------|
| `app.py` | Streamlit UI: Agentic Loop, Demo Mode, Preference Data, Training, Evaluation tabs |
| `config.py` | Central models, paths, judge thresholds, training defaults (APP_VERSION 0.5) |
| `requirements.txt` | Python dependency stack (Streamlit, Transformers, PEFT, TRL, Chroma, etc.) |
| `.env.example` | Safe shareable configuration template (no secrets). Do **not** treat as live `.env` |
| `README.md` | Project overview and dual-path model honesty table |

## Live agentic feedback loop

| File | Role |
|------|------|
| `src/pipeline/agentic_feedback.py` | Orchestrates investigate → feedback → revise → verify → preference gate |
| `src/pipeline/cycle_schema.py` | Structured cycle / stage data shapes used by the UI |
| `src/pipeline/loop.py` | Related pipeline loop helpers |
| `src/demo/agentic_panel.py` | Streamlit staging UI for the agentic cycle |
| `src/demo/prepare.py` | Demo preparation helpers |

## Supervisory agent / judge / tools

| File | Role |
|------|------|
| `src/judge/agentic_runtime.py` | ReAct-style autonomy: agentic / agentic_degraded / fixed_workflow_fallback |
| `src/judge/agent.py` | Agent decision / investigation logic |
| `src/judge/tool_registry.py` | Tool registration for the supervisory agent |
| `src/judge/tools.py` | Tool implementations (retrieve, analyze, inspect, etc.) |
| `src/judge/preference.py` | Preference pair creation and eligibility/trust gates |
| `src/judge/verifier.py` | Rule / deterministic verification helpers |
| `src/judge/scoring.py` | Score assembly / repair related logic |
| `src/judge/prompts.py` | Judge/agent prompts |
| `src/judge/schemas.py` | Structured judgment schemas |
| `src/judge/rubric.py` | Evaluation rubric |

## Models

| File | Role |
|------|------|
| `src/models/target_llm.py` | Target LLM interface (Ollama / HF dual path) |
| `src/models/judge_llm.py` | Judge / supervisory LLM client configuration |
| `src/models/ollama_client.py` | Ollama HTTP client |

## Retrieval and memory

| File | Role |
|------|------|
| `src/retrieval/chroma_store.py` | Chroma vector store setup and queries |
| `src/retrieval/safety_retriever.py` | Safety principle / example retrieval |
| `src/memory/db.py` | SQLite persistence (conversations, evaluations, preferences) |

## Offline DPO + LoRA and evaluation

| File | Role |
|------|------|
| `src/training/dpo_train.py` | TRL DPOTrainer + PEFT LoRA training entry |
| `src/training/feasibility.py` | Training feasibility / honesty checks |
| `src/eval/benchmark.py` | HF baseline vs HF+adapter evaluation helpers |
| `src/eval/behavioral.py` | Behavioral evaluation logic |
| `src/eval/behavioral_metrics.py` | Behavioral metric helpers |
| `src/eval/constraints.py` | Format / constraint checking used in verification |

## Reading tip for code-backed report sections

1. Start with `app.py` + `src/pipeline/agentic_feedback.py` for the live loop narrative.
2. Read `src/judge/agentic_runtime.py` + `tool_registry.py` + `tools.py` for agent autonomy and tools.
3. Read `preference.py` then `dpo_train.py` for preference → offline training separation.
4. Read `benchmark.py` only as **infrastructure** for baseline/optimized eval — do not invent scores.
